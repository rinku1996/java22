function validateform()
{
var uniqueid=document.myform.uniqueid.value;  
  if(uniqueid.length<6 || uniqueid.length>6){  
  alert("Please enter Correct Unique ID");  
  return false;  
  } 
  
  var leaves=document.myform.leaves.value;
  if(leaves.length<2 || leaves.length>2)
	  {
	  alert("please enter two digits")
	  return false;
	  }

}


