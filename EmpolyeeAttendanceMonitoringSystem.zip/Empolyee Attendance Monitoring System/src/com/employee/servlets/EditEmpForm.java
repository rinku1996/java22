package com.employee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.beans.EmployeeBean;
import com.employee.dao.EmployeeDao;

/**
 * @author jradhak1
 *
 */
@WebServlet("/EditEmpForm")
public class EditEmpForm extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Edit Employee Form</title>");

		out.println("<link rel='stylesheet' href='pages.css'/>");
		out.println("</head>");
		out.println("<body>");

		// request.getRequestDispatcher("navadmin.html").include(request, response);

		String sid = request.getParameter("id");
		int id = Integer.parseInt(sid);

		EmployeeBean bean = EmployeeDao.viewById(id);
		request.getRequestDispatcher("navadmin.html").include(request, response);

		out.print(
				"<center><div class='h1'><b> Edit Employee </b><br><br><br><form action='EditEmployee' method='post' autocomplete='on' style='width:300px;'>");
		out.print("<input type='hidden' name='id' value='" + bean.getId() + "'/>");
		out.print("<table><tr><td><font size='4' color='black'>Uniqe ID </td><td><input name='uniqueid' value='"
				+ bean.getUniqueId()
				+ "' id='uniqueid1'style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'>Name </td><td><input name='name' value='" + bean.getName()
				+ "' id='name1'style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'>E-mail </td><td><input name='email' value='" + bean.getEmail()
				+ "' id='email1' autocomplete='off' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print(
				"<tr><td><font size='4' color='black'>Password </td><td><input type='password' name='password' value='"
						+ bean.getPassword()
						+ "' id='password1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'>Mobile Number </td><td><input name='mobile' value='"
				+ bean.getMobile()
				+ "' id='mobile1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'>Designation </td><td><input name='designation' value='"
				+ bean.getDesignation()
				+ "' id='designation1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		
		out.print("<tr><td><font size='4' color='black'>Salary</td><td><input name='salary' value='" + bean.getSalary()
				+ "' id='salary1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'></td><td><input type='hidden' name='attendance' value='" + bean.getAttendance()
		+ "' id='attendance1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'></td><td><input type='hidden' name='leaves' value='" + bean.getLeaves()
		+ "' id='leaves1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'></td><td><input type='hidden' name='lop' value='" + bean.getLop()
		+ "' id='lop1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		
		out.print("<tr></table><br><br><button type='submit' style='width:200px;height:30px;'>Update</button>");
		out.print("</form></div></center>");

		out.close();

	}
}
