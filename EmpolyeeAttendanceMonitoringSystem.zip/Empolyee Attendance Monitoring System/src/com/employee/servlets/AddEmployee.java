package com.employee.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.employee.beans.EmployeeBean;
import com.employee.dao.EmployeeDao;

/**
 * @author jradhak1
 *
 */
@WebServlet("/AddEmployee")
public class AddEmployee extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Add Employee</title>");
		out.println("</head>");
		out.println("<body>");

		request.getRequestDispatcher("navadmin.html").include(request, response);

		// out.print("<br><br><br><br><center><h4>Librarian added un
		// successfully</h4></center>");
		String uniqueid = request.getParameter("uniqueid");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String mobile = request.getParameter("mobile");
		String designation = request.getParameter("designation");
		String attendance = request.getParameter("attendance");
		String leaves = request.getParameter("leaves");
		String lop = request.getParameter("lop");
		String salary = request.getParameter("salary");
		String tattendance = request.getParameter("tattendance");
		String tsalary = request.getParameter("tsalary");

		if (EmployeeDao.authenticateEmail(email)) {
			HttpSession session = request.getSession();
			session.setAttribute("email", email);
			out.print("<br><br><br><br><br><center><h1>E-mail already exists</h1></center>");

		} else if (EmployeeDao.authenticateMobile(mobile)) {
			HttpSession session = request.getSession();

			session.setAttribute("mobile", mobile);
			out.print("<br><br><br><br><br><center><h1>Mobile No already exists</h1></center>");

		}
		else if (EmployeeDao.authenticateuniqueId(uniqueid)) {
			HttpSession session = request.getSession();

			session.setAttribute("uniqueid", uniqueid);
			out.print("<br><br><br><br><br><center><h1>Unique ID already exists</h1></center>");

		}

		else {
			EmployeeBean bean = new EmployeeBean(uniqueid, name, email, password, mobile, designation, attendance,
					leaves, lop, salary, tattendance, tsalary);

			EmployeeDao.save(bean);
			out.print("<br><br><br><br><br><center><h1>Employee added successfully</h1></center></body></html>");
			// request.getRequestDispatcher("addempform.html").include(request, response);
		}

		out.close();
	}

}
