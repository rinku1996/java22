package com.employee.beans;

/**
 * @author jradhak1
 *
 */
public class EmployeeBean {
	private int id;
	private String uniqueid, name, email, password, designation;
	private String mobile;
	private String attendance, leaves, lop, salary, tattendance, tsalary;

	public EmployeeBean() {
	}

	public EmployeeBean(int id, String uniqueid, String name, String email, String password, String mobile,
			String designation, String attendance, String leaves, String lop, String salary, String tattendance,
			String tsalary) {
		super();
		this.id = id;
		this.uniqueid = uniqueid;
		this.name = name;
		this.email = email;
		this.password = password;
		this.mobile = mobile;
		this.designation = designation;
		this.attendance = attendance;
		this.leaves = leaves;
		this.lop = lop;
		this.salary = salary;
		this.tattendance = tattendance;
		this.tsalary = tsalary;
	}

	public EmployeeBean(String uniqueid, String name, String email, String password, String mobile, String designation,
			String attendance, String leaves, String lop, String salary, String tattendance, String tsalary) {
		super();
		this.uniqueid = uniqueid;
		this.name = name;
		this.email = email;
		this.password = password;
		this.mobile = mobile;
		this.designation = designation;
		this.attendance = attendance;
		this.leaves = leaves;
		this.lop = lop;
		this.salary = salary;
		this.tattendance = tattendance;
		this.tsalary = tsalary;
	}

	public String getTattendance() {
		return tattendance;
	}

	public void setTattendance(String tattendance) {
		this.tattendance = tattendance;
	}

	public String getTsalary() {
		return tsalary;
	}

	public void setTsalary(String tsalary) {
		this.tsalary = tsalary;
	}

	public String getAttendance() {
		return attendance;
	}

	public void setAttendance(String attendance) {
		this.attendance = attendance;
	}

	public String getLeaves() {
		return leaves;
	}

	public void setLeaves(String leaves) {
		this.leaves = leaves;
	}

	public String getLop() {
		return lop;
	}

	public void setLop(String lop) {
		this.lop = lop;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUniqueId() {
		return uniqueid;
	}

	public void setUniqueId(String uniqueid) {
		this.uniqueid = uniqueid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesigantion(String designation) {
		this.designation = designation;
	}
}
