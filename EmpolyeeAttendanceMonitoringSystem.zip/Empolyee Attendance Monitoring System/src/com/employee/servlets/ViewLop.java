package com.employee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.beans.EmployeeBean;
import com.employee.dao.EmployeeDao;

/**
 * @author jradhak1
 *
 */
@WebServlet("/ViewLop")
public class ViewLop extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		request.getRequestDispatcher("emplogin.html").include(request, response);

		request.getRequestDispatcher("search.html").include(request, response);

		out.println("<title>View Lops</title>");

		out.close();

	}
}
