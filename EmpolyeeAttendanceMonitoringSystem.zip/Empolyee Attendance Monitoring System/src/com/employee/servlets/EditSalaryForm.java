package com.employee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.employee.beans.EmployeeBean;
import com.employee.dao.EmployeeDao;

@WebServlet("/EditSalaryForm")
public class EditSalaryForm extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Edit Employee Form</title>");

		out.println("<link rel='stylesheet' href='pages.css'/>");
		out.println("</head>");
		out.println("<body>");
		String sid = request.getParameter("id");
		int id = Integer.parseInt(sid);
		EmployeeBean bean = EmployeeDao.viewById(id);

		request.getRequestDispatcher("adminstafflogin.html").include(request, response);
		out.print(
				"<br><input type='button' name='Sumbit' value='Update Salary' onclick='javascript:mulNumbers()' style='width:200px;height:50px;background-color:gold;margin-left:200px;'>");
		out.print("<input type='button' name='Sumbit' value='Update Lops' onclick='javascript:subNumbers()' style='width:200px;height:50px;background-color:#8B008B;color:white;margin-left:850px;margin-top:-100px;'/>");
		out.print(
				"<center><div class='h1'><b> Update Salary and LOP s </b><br><br><br><form action='EditLeaves' method='post' autocomplete='on' style='width:300px;'>");
		// out.print("<input type='hidden' name='id' value='"+bean.getId()+"'/>");
		// out.print("<table><tr><td><font size='4' color='black'>Unique ID
		// </td><td><input name='uniqueid' value='"+bean.getUniqueId()+"'
		// id='uniqueid1'style='width:150px;height:30px;font-size:15px;border-radius:5px
		// 5px 5px 5px;'></td></tr>");
		out.print("<table><tr><td><font size='4' color='black'></td><td><input type='hidden' name='id' value='"
				+ bean.getId()
				+ "' id='id1'style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");

		out.print("<tr><td><font size='4' color='black'> </td><td><input type='hidden' name='name' value='"
				+ bean.getName()
				+ "' id='name1'style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'></td><td><input type='hidden'  name='email' value='"
				+ bean.getEmail()
				+ "' id='email1' autocomplete='off' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print(
				"<tr><td><font size='4' color='black'></td><td><input type='hidden' type='password' name='password' value='"
						+ bean.getPassword()
						+ "' id='password1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'></td><td><input type='hidden' name='mobile' value='"
				+ bean.getMobile()
				+ "' id='mobile1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'></td><td><input type='hidden' name='designation' value='"
				+ bean.getDesignation()
				+ "' id='designation1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");

		out.print("<tr><td><font size='4' color='black'>Unique ID </td><td><input name='uniqueid' value='"
				+ bean.getUniqueId()
				+ "' id='uniqueid1'style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'>Attendance </td><td><input name='attendance' value='"
				+ bean.getAttendance()
				+ "' id='attendance1'style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");

		out.print("<tr><td><font size='4' color='black'>Leaves </td><td><input name='leaves' value='" + bean.getLeaves()
				+ "' id='leaves1`' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'>Lop</td><td><input type='text' name='lop' value='"
				+ bean.getLop()
				+ "' id='lop1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");

		out.print("<tr><td><font size='4' color='black'>Salary </td><td><input name='salary' value='" + bean.getSalary()
				+ "' id='salary1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print("<tr><td><font size='4' color='black'>Total Attendance </td><td><input name='tattendance' value='"
				+ bean.getTattendance()
				+ "' id='tattendance1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");
		out.print(
				"<tr><td><font size='4' color='black'>Total Salary </td><td><input name='tsalary' value='' id='tsalary1' style='width:150px;height:30px;font-size:15px;border-radius:5px 5px 5px 5px;'></td></tr>");

		out.print("</table><br><br><button type='submit' style='width:200px;height:30px;'>Update</button>");
		out.print("</form></div></center>");

		out.print("<script language='javascript'>");
		out.print("function subNumbers(){");
		out.print("     var val1 = parseInt(document.getElementById('value1').value);");
		out.print("    var val2 = parseInt(document.getElementById('value2').value);");
		out.print("   var ansD = document.getElementById('lop1');");
		out.print("   ansD.value = val1 - val2;  }");
		out.print("function mulNumbers()");
		out.print("{");
		out.print("var val3 = parseInt(document.getElementById('value3').value);");
		out.print("var val4 = parseInt(document.getElementById('value4').value);");
		out.print("var ansM = document.getElementById('tsalary1');");
		out.print("ansM.value = val3 *val4;");
		out.print("}");
		out.print("</script>");

		//View Lop's
		out.print("<input type='hidden' id='value1' name='value1' value="+bean.getLeaves()+">");
		out.print("<input type='hidden' id='value2' name='value2'value="+bean.getLop()+">");

		//out.print("<input type='button' name='Sumbit' value='Click here' onclick='javascript:subNumbers()'/>");
		// out.print("Addition = <input type='text' id='tattendance1' name='tattendance'
		// value=''/><br>");

		out.print("<input type='hidden' id='value3' name='value3' value=" + bean.getTattendance() + ">");
		out.print("<input type='hidden' id='value4' name='value4' value=" + bean.getSalary() + ">	");

		//out.print("<input type='button' name='Sumbit' value='Update Salary' onclick='javascript:mulNumbers()'/>");
		// out.print("Multiplication = <input type='text' id='tsalary1' name='tsalary'
		// value=''/>");

		out.close();

	}
}
