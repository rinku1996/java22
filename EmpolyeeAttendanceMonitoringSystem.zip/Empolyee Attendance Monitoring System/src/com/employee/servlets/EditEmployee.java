package com.employee.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.beans.EmployeeBean;
import com.employee.dao.EmployeeDao;

/**
 * @author jradhak1
 *
 */
@WebServlet("/EditEmployee")
public class EditEmployee extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String sid = request.getParameter("id");
		int id = Integer.parseInt(sid);
		String uniqueid = request.getParameter("uniqueid");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String mobile = request.getParameter("mobile");
		String designation = request.getParameter("designation");

		String attendance = request.getParameter("attendance");
		String leaves = request.getParameter("leaves");
		String lop = request.getParameter("lop");
		String salary = request.getParameter("salary");
		String tattendance = request.getParameter("tattendance");
		String tsalary = request.getParameter("tsalary");

		EmployeeBean bean = new EmployeeBean(id, uniqueid, name, email, password, mobile, designation, attendance,
				leaves, lop, salary, tattendance, tsalary);
		EmployeeDao.update(bean);
		response.sendRedirect("ViewEmployee");
	}

}
