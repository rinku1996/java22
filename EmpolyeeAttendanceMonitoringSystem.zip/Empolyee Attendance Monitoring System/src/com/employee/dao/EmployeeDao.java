package com.employee.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.employee.beans.EmployeeBean;

/**
 * @author jradhak1
 *
 */
public class EmployeeDao {

	public static int save(EmployeeBean bean) {
		int status = 0;
		try {
			Connection con = DB.getCon();
			PreparedStatement ps = con.prepareStatement(
					"insert into employee1(uniqueid,name,email,password,mobile,designation,attendance,leaves,lop,salary,tattendance,tsalary) values(?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, bean.getUniqueId());
			ps.setString(2, bean.getName());
			ps.setString(3, bean.getEmail());
			ps.setString(4, bean.getPassword());
			ps.setString(5, bean.getMobile());
			ps.setString(6, bean.getDesignation());
			ps.setString(7, bean.getAttendance());
			ps.setString(8, bean.getLeaves());
			ps.setString(9, bean.getLop());
			ps.setString(10, bean.getSalary());
			ps.setString(11, bean.getTattendance());
			ps.setString(12, bean.getTsalary());

			status = ps.executeUpdate();
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	public static int update(EmployeeBean bean) {
		int status = 0;
		try {
			Connection con = DB.getCon();
			PreparedStatement ps = con.prepareStatement(
					"update employee1 set uniqueid=?,name=?,email=?,password=?,mobile=?,designation=?,attendance=?,leaves=?,lop=?,salary=?,tattendance=?,tsalary=? where id=?");
			ps.setString(1, bean.getUniqueId());
			ps.setString(2, bean.getName());
			ps.setString(3, bean.getEmail());
			ps.setString(4, bean.getPassword());
			ps.setString(5, bean.getMobile());
			ps.setString(6, bean.getDesignation());
			ps.setString(7, bean.getAttendance());
			ps.setString(8, bean.getLeaves());
			ps.setString(9, bean.getLop());
			ps.setString(10, bean.getSalary());
			ps.setString(11, bean.getTattendance());
			ps.setString(12, bean.getTsalary());
			ps.setInt(13, bean.getId());
			status = ps.executeUpdate();
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	public static List<EmployeeBean> view() {
		List<EmployeeBean> list = new ArrayList<EmployeeBean>();
		try {
			Connection con = DB.getCon();
			PreparedStatement ps = con.prepareStatement("select * from employee1");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				EmployeeBean bean = new EmployeeBean();
				bean.setId(rs.getInt("id"));
				bean.setUniqueId(rs.getString("uniqueid"));
				bean.setName(rs.getString("name"));
				bean.setEmail(rs.getString("email"));
				bean.setPassword(rs.getString("password"));
				bean.setMobile(rs.getString("mobile"));
				bean.setDesigantion(rs.getString("designation"));
				bean.setAttendance(rs.getString("attendance"));
				bean.setLeaves(rs.getString("leaves"));
				bean.setLop(rs.getString("lop"));
				bean.setSalary(rs.getString("salary"));
				bean.setTattendance(rs.getString("tattendance"));
				bean.setTsalary(rs.getString("tsalary"));

				list.add(bean);
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return list;
	}

	public static EmployeeBean viewById(int id) {
		EmployeeBean bean = new EmployeeBean();
		try {
			Connection con = DB.getCon();
			PreparedStatement ps = con.prepareStatement("select * from employee1 where id=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				bean.setId(rs.getInt(1));
				bean.setUniqueId(rs.getString(2));
				bean.setName(rs.getString(3));
				bean.setPassword(rs.getString(4));
				bean.setEmail(rs.getString(5));
				bean.setMobile(rs.getString(6));
				bean.setDesigantion(rs.getString(7));
				bean.setAttendance(rs.getString(8));
				bean.setLeaves(rs.getString(9));
				bean.setLop(rs.getString(10));
				bean.setSalary(rs.getString(11));
				bean.setTattendance(rs.getString(12));
				bean.setTsalary(rs.getString(13));

			}

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return bean;
	}

	public static int delete(int id) {
		int status = 0;
		try {
			Connection con = DB.getCon();
			PreparedStatement ps = con.prepareStatement("delete from employee1 where id=?");
			ps.setInt(1, id);
			status = ps.executeUpdate();
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	public static boolean authenticate(String email, String password) {
		boolean status = false;
		try {
			Connection con = DB.getCon();
			PreparedStatement ps = con.prepareStatement("select * from employee1 where email=? and password=?");
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				status = true;
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	public static boolean authenticateEmail(String email) {
		boolean status = false;
		try {
			Connection con = DB.getCon();
			PreparedStatement ps = con.prepareStatement("select * from employee1 where email=?");
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				status = true;
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	public static boolean authenticateMobile(String mobile) {
		boolean status = false;
		try {
			Connection con = DB.getCon();
			PreparedStatement ps = con.prepareStatement("select * from employee1 where mobile=?");

			ps.setString(1, mobile);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				status = true;
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	// Authentication Unique ID

	public static boolean authenticateuniqueId(String uniqueid) {
		boolean status = false;
		try {
			Connection con = DB.getCon();
			PreparedStatement ps = con.prepareStatement("select * from employee1 where uniqueid=?");
			ps.setString(1, uniqueid);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				status = true;
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}
	// Authentication Unique Leaves

	public static boolean authenticateLeaves(String Leaves) {
		boolean status = false;
		try {
			Connection con = DB.getCon();
			PreparedStatement ps = con.prepareStatement("select * from leaves where Leaves=?");
			ps.setString(1, Leaves);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				status = true;
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}
	
	
	
	


}
